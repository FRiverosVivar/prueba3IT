import { Component, OnInit } from '@angular/core';
import { RestserviceService } from './../../services/restservice.service'
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
  inputValue:string
  responseUsers: any;
  users: any[];
  allUsers: any[];
  postRes: any;
  usersPosts: any[];
  loadedUser: boolean;
  activatedCard:boolean
  selectedUser: any;
  constructor(
    private restService: RestserviceService
  ) {
    this.inputValue = '';
    this.loadedUser = false;
    this.users = [];
    this.allUsers = [];
    this.usersPosts = [];
    this.activatedCard = false;
  }

  ngOnInit(): void {
    this.getUsers();
  }
  getUsers(){
    let obj = this.restService.getUsers()
    obj.subscribe(res => {
      console.log(res)
      this.responseUsers = res
      this.responseUsers.forEach((user:any) =>{
        let userAux = {
          id: user.id,
          name: user.name,
          username: user.username,
          email: user.email,
          address: user.address,
          phone: user.phone,
          website: user.website,
          company: user.company,
          post: null
        }
        console.log(userAux)
        this.users.unshift(userAux)
      })
    })
    this.allUsers = this.users;
    
    let postObservable = this.restService.getPost()
    postObservable.subscribe(res => {
      this.postRes = res
      this.postRes.forEach((post:any) =>{
        let userPost = {
          userId: post.userId,
          id: post.id,
          title: post.title,
          body: post.body
        }
        this.usersPosts.unshift(userPost)
      })
      this.loadedUser = true;
    })
    setTimeout(() => {
      if(this.loadedUser == true){
        this.assignPostsToUsers()
      }
    },2000)
    
  }
  assignPostsToUsers(){

    this.users.forEach((user)=>{
      let userPost: any[] = [];
      this.usersPosts.forEach((post)=>{
        if(user.id == post.userId){
          userPost.unshift(post)
        }
      })
      user.post = userPost
    })

  }
  filterUsers(inputValue:string){
    this.users = [];
    this.allUsers.forEach((user)=>{
      if(user.name.indexOf(inputValue) >=0){
        this.users.unshift(user)
      }
    })
  }
  deleteFilter(){
    this.inputValue = ''
    this.users = this.allUsers;
    this.activatedCard = false;
    this.selectedUser = null;

  }
  getFixedBirthdate(){
    let birth = new Date()
    let year = birth.getFullYear()
    year -= 20;
    let month = (birth.getMonth()+1)
    if(month == 1){
      year -= 1;
      month = 12;
    }

    return (birth.getDate()+'/'+month+'/'+year)
  }
  displayUserCard(user:any){
    this.activatedCard = true
    this.selectedUser = user;
    console.log(user)
  }

}
