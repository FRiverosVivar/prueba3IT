import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RestserviceService {
  private url: string;
  constructor(
    private http: HttpClient
  ) {
    this.url = 'https://jsonplaceholder.typicode.com';
  }
  getUsers(){
    return this.http.request('GET', this.url + "/users", {responseType:'json'});
  }
  getPost(){
    return this.http.request('GET', this.url + "/posts", {responseType:'json'});
  }
}
